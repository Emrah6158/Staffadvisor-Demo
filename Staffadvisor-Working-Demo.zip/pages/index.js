
export default function Home() {
  return (
    <div style={{ fontFamily: 'Arial', padding: 20 }}>
      <h1>Staffadvisor'a Hoşgeldiniz 👋</h1>
      <p>Bu, demo uygulamanın ana sayfasıdır. Her şey çalışıyor!</p>
    </div>
  );
}
