
export default function Home() {
  return (
    <main style={{ padding: 20, fontFamily: 'Arial' }}>
      <h1>Staffadvisor'a Hoşgeldiniz 👋</h1>
      <p>Bu versiyon App Router uyumlu ve Vercel'de sorunsuz çalışır.</p>
    </main>
  );
}
